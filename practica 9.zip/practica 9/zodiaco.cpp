#include <stdio.h>

int main()
{
  int numero; 
 do{
 
    printf( "\n Listado de signos del zodiaco:\n" );
    printf( "1. Aries \n" );
    printf( "2. Tauro \n" );
    printf( "3. Geminis \n");
    printf( "4. Cancer \n");
    printf( "5. Leo \n" );
    printf( "6. Virgo \n" );
    printf( "7. Libra \n" );
    printf( "8. Escorpio \n" );
    printf( "9. Sagitario \n" );
    printf( "10. Capricornio \n" );
    printf( "11. Acuario \n" );
    printf( "12. Piscis \n" );
    printf( "\n Introduzca numero de signo:\n\n ");

    scanf( "%d", &numero );

    switch ( numero )
    {
        case  1 :
        case  5 :
        case  9 : printf( "tipo Fuego.\n" );
                  break;
        case  2 :
        case  6 :
        case 10 : printf( "tipo Tierra.\n" );
                  break;
        case  3 :
        case  7 :
        case 11 : printf( "tipo Aire.\n" );
                  break;
        case  4 :
        case  8 :
        case 12 : printf( "tipo Agua.\n" );
                  break;
    }
 }while(numero>=1 && numero<=12);

     return 0;
}
