#include<stdio.h>
int main()
{	
	int op;
	int o;
	do
	{
			printf("\t MENU \n");
		printf(" ELIGE UNA DE ESTAS OPCIONES \n");
		printf("1)comedia\n");
		printf("2)accion \n");
		printf("3)fantasia\n");
		scanf("%d",&op);
		switch(op)
		{
			default:
			printf("\n OPCION NO VALIDA\n");
			break;
			case 1:
				printf("\n �que risa!\n");
				break;
			case 2:
			printf("\n muy emocionante\n");
				break;
			case 3:
				printf("\n que buen gusto \n");
				break;
		}
		printf("\n DESEAS REALIZAR OTRA OPERACION? 4=SI 5=NO \n");
		
		scanf("%d",&o);
		
	}while  (o !=5);
	return 0;
}

