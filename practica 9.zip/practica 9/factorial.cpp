#include <stdio.h>
#include <conio.h>

int main()
{
	int op;
	do
	{
		int fact=0;
		printf("escribe el numero a calcular en factorial\n");
		scanf("%d",&fact);
		int temp=fact-1;
		int r=fact;
		while (temp>=1)
		{
		r=r*temp;
		temp--;
		}
		printf("\n el factorial de %d es: %d\n",fact,r);
		getch();
		
		printf("\n DESEAS REALIZAR OTRA OPERACION? 1=SI 2=NO \n");
	
		scanf("%d",&op);
	}while  (op ==1);
}
